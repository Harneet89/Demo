import io.restassured.RestAssured;
import io.restassured.http.ContentType;

import static io.restassured.RestAssured.given;

import javax.annotation.meta.When;

public class Basics {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
           
		//BaseURL
		RestAssured.baseURI="https://www.vanguardinvestments.com.au";
		given().
	   when().
	   get("/retail/mvc/getNavPriceList.jsonp").
	   then().assertThat().statusCode(200).and().contentType(ContentType.JSON);
	  
	          
	}

}
